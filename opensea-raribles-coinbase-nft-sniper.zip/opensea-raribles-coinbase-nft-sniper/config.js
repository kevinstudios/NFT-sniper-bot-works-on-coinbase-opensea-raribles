var myaddress = "your public wallet address" // your public wallet address
var myprivatekey = "your privatekey of the wallet address" // the privatekey of the wallet address
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with accessibility example (hardwarewallets)
var marketplace = "1" //1=Opensea , 2=Raribles , 3=coinbaseNFT
var networks = "1" //1 = ETH ,  2 = Polygon 
var maxspend = "0.5" // max eth you want to spend on the NFT. Note: Make sure you have that amount in the wallet you provided.
var NFTcollectionID = "boredapeyachtclub" 
//for the opensea collection name "https://opensea.io/collection/boredapeyachtclub" <- take this part of the url for example: "boredapeyachtclub"
//for the Raribles "https://rarible.com/boredapeyachtclub/items" <- take this part of the url for example: "boredapeyachtclub"
//for the coinbaseNFT "https://nft.coinbase.com/collection/ethereum/0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D" <- take this part of the url for example: "0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D"